<?php
/**
 * The right sidebar template
 *
 *
 * @package Customizr
 * @since Customizr 3.1.0
 */

dynamic_sidebar( 'right' );

?>

