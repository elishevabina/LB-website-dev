		</div>
		<div class="footer clear">
        	<p>&copy; <?php the_time(__('Y')) ?> <?php bloginfo('name'); ?>. All Rights Reserved.</p>
            <p class="about">Theme by <a href="http://www.wpshower.com" title="WPSHOWER">WPSHOWER</a> & <a href="http://www.moodyguy.net/">MOODYGUY</a></p>
        </div>
	</div><!-- #wrapper -->
<?php wp_footer(); ?>
</body>
</html> 
