
Tagline under logo can only support one line of text.

Menu styling best supports one line of links. 





Install Steps:
--------------

1. Activate the theme
2. Go to the Theme Option page
3. Setup theme options


License
---------------------
Hazen WordPress Theme, Copyright 2013 ThemeAlley.com
Hazen is distributed under the terms of the GNU GPL v2


How to feature Posts In slider?
-------------------------------------
SImply put all the posts you want to feature in a seperate category and select this category in the dropdown for "Select Category" in slider tab of theme options.


How to Show images in featured posts?
------------------------------------------
Simply set a featured image in the posts you featured.



------------------------------------------

Options Framework : GPL v2 https://github.com/devinsays/options-framework-theme

Social icons designed by themealley and distributed under the terms of the GNU GPL v2

Wilto slider license : MIT License. http://wil.to/3a

TinyNav license : MIT License http://tinynav.viljamis.com

Respond.js license : MIT/GPLv2 Lic. j.mp/respondjs

CSS drop down menu license : MIT/GPLv2 http://www.lwis.net/free-css-drop-down-menu

PT Sans font license : http://www.paratype.com/public/

Bitstream font license : http://www.fontsquirrel.com/fonts/Bitstream-Vera-Sans#eula

TitilliumText font license : http://www.fontsquirrel.com/license/TitilliumText

Chunkfive font license : http://www.fontsquirrel.com/license/ChunkFive

Color Picker : GPL http://www.eyecon.ro/colorpicker/

Wp Title function courtesy of _S theme


-------------------------------------------

PRO features :

2 Magazine Layouts, 5 Sliders, Polls, Feedburner, Related Posts, Social Share, Contact forms


Lite features :

Standard Layout, 1 Slider 