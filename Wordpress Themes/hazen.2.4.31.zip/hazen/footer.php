



                </div>	
                <!-- Content Section ends here -->	


                                                              
			</div>	
			<!-- Wrapper three ends here -->	
                                               


                
                <!-- Footer Section starts here -->
                <div id="footer_section_cont">
                    
                    <div class="slider_container">                 
                
                
                        <div id="footer_section">
                            
                            
                                                    <div id="bottomfooterwidgetcontainer">
                                                        <div class="bottomfooterwidgety">

                                                                <div class="footerp"><?php _e('&copy; All rights reserved.', 'Hazen') ?></div>
                                                                <?php if( is_home() || is_front_page() ): ?>
                                                                <div class="footercredit">
																	<?php _e('Powered by ', 'Hazen') ?><a href="http://www.wordpress.org/"><?php _e('WordPress', 'Hazen') ?></a> <?php _e(' & ', 'Hazen') ?> <a href="http://www.themealley.com/"><?php _e('Hazen Theme', 'Hazen') ?></a>
                                                                </div>
                                                                <?php else: ?>
                                                                <div class="footercredit">
																	<?php _e('Powered by ', 'Hazen') ?><a href="http://www.wordpress.org/"><?php _e('WordPress', 'Hazen') ?></a>
                                                                </div>                                                                
                                                                <?php endif;?>

                                                        </div>
            

                                                    </div>	                
                            
                            
                            
                            
                   
                         </div>	
                         <!-- Footer Section ends here -->	
                    </div>        
                
                </div>                              
            
		</div>	
		<!-- Wrapper two ends here -->  
        
        
        
                 
	</div>	
	<!-- Wrapper four ends here -->	            				
	</div>	
	<!-- Wrapper one ends here -->	



<?php wp_footer(); ?>
</body>
</html>